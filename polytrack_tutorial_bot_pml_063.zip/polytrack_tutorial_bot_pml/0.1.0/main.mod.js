import { PolyMod, MixinType } from "https://cdn.polymodloader.com/cb/PolyTrackMods/PolyModLoader/0.6.3/PolyTypes.js";

const ROUTE = [
  {x:320,y:55,z:20},
  {x:260,y:55,z:0},
  {x:180,y:55,z:0},
  {x:140,y:45,z:0},
  {x:120,y:35,z:0},
  {x:100,y:25,z:0},
  {x:80,y:15,z:0},
  {x:60,y:5,z:0},
  {x:-20,y:0,z:0},
  {x:-80,y:0,z:0},
  {x:-180,y:0,z:0},
  {x:-160,y:0,z:-20},
  {x:-100,y:10,z:-80},
  {x:-100,y:10,z:-40},
  {x:-120,y:20,z:40},
  {x:-120,y:20,z:60},
  {x:-140,y:20,z:140},
  {x:-200,y:20,z:220},
  {x:-260,y:20,z:260},
  {x:-300,y:20,z:280}
];

const WORKER_HELPERS = `
(() => {
  const route = ${JSON.stringify(ROUTE)};
  const state = Object.create(null);
  const routeIndex = Object.create(null);

  const dist2 = (a,b) => {
    const x=a.x-b.x, y=a.y-b.y, z=a.z-b.z;
    return x*x+y*y+z*z;
  };

  function segmentPoint(a,b,p) {
    const abx=b.x-a.x, aby=b.y-a.y, abz=b.z-a.z;
    const apx=p.x-a.x, apy=p.y-a.y, apz=p.z-a.z;
    const den=abx*abx+aby*aby+abz*abz;
    let t=den ? (apx*abx+apy*aby+apz*abz)/den : 0;
    if(t<0)t=0; else if(t>1)t=1;
    return {x:a.x+abx*t,y:a.y+aby*t,z:a.z+abz*t,t};
  }

  function nearest(p, start) {
    let best={distance:Infinity,index:start,point:route[start]};
    for(let i=start;i<route.length-1;i++) {
      const q=segmentPoint(route[i],route[i+1],p);
      const d=dist2(p,q);
      if(d<best.distance) best={distance:d,index:i,point:q};
    }
    return best;
  }

  function lookAhead(p, speed, start) {
    const n=nearest(p,start);
    let ahead=Math.max(18,Math.min(75,(speed||0)*0.42));
    let i=n.index, here=n.point;
    while(i<route.length-1 && ahead>0) {
      const end=route[i+1];
      const dx=end.x-here.x, dy=end.y-here.y, dz=end.z-here.z;
      const len=Math.hypot(dx,dy,dz);
      if(len>=ahead) {
        const f=ahead/Math.max(len,1e-6);
        return {x:here.x+dx*f,y:here.y+dy*f,z:here.z+dz*f};
      }
      ahead-=len;
      i++;
      here=route[i];
    }
    return route[route.length-1];
  }

  function forward(q) {
    const qx=q.x,qy=q.y,qz=q.z,qw=q.w;
    const x=0,y=0,z=-1;
    const ix=qw*x+qy*z-qz*y;
    const iy=qw*y+qz*x-qx*z;
    const iz=qw*z+qx*y-qy*x;
    const iw=-qx*x-qy*y-qz*z;
    return {
      x:ix*qw+iw*-qx+iy*-qz-iz*-qy,
      y:iy*qw+iw*-qy+iz*-qx-ix*-qz,
      z:iz*qw+iw*-qz+ix*-qy-iy*-qx
    };
  }

  function controlsFor(s, carId) {
    if(!s || !s.hasStarted || s.finishFrames !== null) {
      return {up:true,right:false,down:false,left:false,reset:false};
    }
    let idx=routeIndex[carId] ?? 0;
    while(idx<route.length-1 && dist2(s.position,route[idx+1])<22*22) idx++;
    const near=nearest(s.position,idx);
    if(near.index>idx) idx=near.index;
    routeIndex[carId]=idx;

    const target=lookAhead(s.position,s.speedKmh,idx);
    const f=forward(s.quaternion);
    const dx=target.x-s.position.x;
    const dz=target.z-s.position.z;
    const dl=Math.hypot(dx,dz)||1;
    const fl=Math.hypot(f.x,f.z)||1;
    const fx=f.x/fl, fz=f.z/fl;
    const tx=dx/dl, tz=dz/dl;
    const angle=Math.atan2(fx*tz-fz*tx,fx*tx+fz*tz);
    const abs=Math.abs(angle);

    let up=true, down=false;
    if(abs>0.95 && s.speedKmh>75) { up=false; down=true; }
    else if(abs>0.62 && s.speedKmh>120) { up=false; down=true; }
    else if(abs>0.42 && s.speedKmh>180) { up=false; }

    return {
      up,
      right: angle>0.055,
      down,
      left: angle<-0.055,
      reset: false
    };
  }

  function decodeCarState(buf) {
    const dv=new DataView(buf.buffer,buf.byteOffset,buf.byteLength);
    let o=0;
    const frames=dv.getUint8(o)|(dv.getUint8(o+1)<<8)|(dv.getUint8(o+2)<<16); o+=3;
    const speedKmh=dv.getFloat32(o,true); o+=4;
    const flags=dv.getUint8(o++);
    let finishFrames=null;
    if(flags&2) { finishFrames=dv.getUint8(o)|(dv.getUint8(o+1)<<8)|(dv.getUint8(o+2)<<16); o+=3; }
    const nextCheckpointIndex=dv.getUint16(o,true); o+=2;
    const position={x:dv.getFloat32(o,true),y:dv.getFloat32(o+4,true),z:dv.getFloat32(o+8,true)}; o+=12;
    const quaternion={x:dv.getFloat32(o,true),y:dv.getFloat32(o+4,true),z:dv.getFloat32(o+8,true),w:dv.getFloat32(o+12,true)};
    return {
      frames,speedKmh,
      hasStarted:!!(flags&1),
      finishFrames,
      hasCheckpointToRespawnAt:!!(flags&4),
      nextCheckpointIndex,position,quaternion
    };
  }

  globalThis.__polyTrackTutorialBot = {
    state, controlsFor, decodeCarState, route,
    enabled: true
  };
})();
`;

const REPLACE_N = `
t.ccall(
              "updateCarModel",
              "void",
              [
                "number",
                "boolean",
                "boolean",
                "boolean",
                "boolean",
                "boolean",
                "number",
              ],
              [e.id, r.up, r.right, r.down, r.left, r.reset, i],
            );
            return new Uint8Array(t.HEAPU8.buffer, i, 227).slice().buffer;
`;

const BOT_N = `
            if (e.userControls && globalThis.__polyTrackTutorialBot?.enabled) {
              const last = globalThis.__polyTrackTutorialBot.state[e.id];
              if (last) r = globalThis.__polyTrackTutorialBot.controlsFor(last, e.id);
              else r = {up:true,right:false,down:false,left:false,reset:false};
            }

            t.ccall(
              "updateCarModel",
              "void",
              [
                "number",
                "boolean",
                "boolean",
                "boolean",
                "boolean",
                "boolean",
                "number",
              ],
              [e.id, r.up, r.right, r.down, r.left, r.reset, i],
            );
            const __ptBuffer = new Uint8Array(t.HEAPU8.buffer, i, 227).slice();
            if (e.userControls && globalThis.__polyTrackTutorialBot?.enabled) {
              try {
                globalThis.__polyTrackTutorialBot.state[e.id] = globalThis.__polyTrackTutorialBot.decodeCarState(__ptBuffer);
              } catch (_) {}
            }
            return __ptBuffer.buffer;
`;

class TutorialBot extends PolyMod {
  constructor() {
    super();
    this.modName = "PolyTrack Tutorial Bot";
    this.modAuthor = "OpenAI";
    this.modID = "polytrack-tutorial-bot";
    this.modVersion = "0.1.0";
  }

  init(pml) {
    pml.registerSimWorkerMixin({
      type: MixinType.INSERT,
      token: "const e = [],",
      func: WORKER_HELPERS,
    });

    pml.registerSimWorkerMixin({
      type: MixinType.REPLACEBETWEEN,
      tokenStart: 't.ccall(\n              "updateCarModel",',
      tokenEnd: 'return new Uint8Array(t.HEAPU8.buffer, i, 227).slice().buffer;',
      func: BOT_N,
    });
  }
}

export let polyMod = new TutorialBot();
